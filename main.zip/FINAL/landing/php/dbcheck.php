
<?php
//include("session.php");
//session_start();

//if(isset($_SESSION["login"])||$_SESSION["adminLogin"]||$_SESSION["employeeLogin"])
	// if($_SESSION["login"]!=""||$_SESSION["adminLogin"]!=""||$_SESSION["employeeLogin"]!="")
	// {
	// 	echo "<h1>ALREADY SOMEONE LOGGED IN</h1>";
	// }
	// else
	// {
	
	
	$val=$_POST["email"];
	if(isset($_POST["email"]) && isset($_POST["pass"]))
	{
		$query="select * from user";
		$queryVerified="select * from user where email='".$val."'";
		$res=getDataFromDB($query);
		if($res==true)
		{
			$vres=getVerify($queryVerified);
			if($vres==true)
			{
				$userType=userTypes($queryVerified);
				if($userType=="admin")
				{
					echo "<BR><BR>GOING ADMIN PAGE";
					session_start();
					$_SESSION["adminLogin"]=true;
					header("Location:../admin.php");
					
				}
				else if($userType=="employee")
				{
					session_start();
					$_SESSION["employeeLogin"]=true;
					echo "<BR><BR>GOING employee PAGE";
				}
				else if($userType=="user")
				{
					session_start();
					$_SESSION["login"]=true;
					echo "<BR><BR>GOING user PAGE";
					header("Location:../index.php");
				}
				else
				{
					echo "THERE ARE SOME TYPE ERrOR";
				}
				echo "Access granted";
				//header("Location:../index.php");
			}
			else
			{
				echo "NOT VERIFIED,please wait for the admin to verify the account";
			}
			
		}
		else
		{
			echo "User Name Or Password Error";
		}	
	}
//}
	
	function getDataFromDB($sql){
	//include("session.php");	
	//session_start();
		$conn = mysqli_connect("localhost", "root", "","pcBuilder");
	
	$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	$arr=array();
	$counter=0;
	$cnt =0;
	while($row = mysqli_fetch_assoc($result)) 
	{
		$counter++;
		$arr[]=$row;
	}
	
	//echo "<pre>";print_r($arr);echo " </pre>";
	
	//$pass=MD5($_POST['pword']);
	
	//echo "<pre>";print_r($pass);echo " </pre>";
	
	$retval=false;
	
	for($cnt=0;$cnt<$counter;$cnt++)
	{
		
		if($arr[$cnt]["email"]==$_POST["email"] && $arr[$cnt]["user_pass"]==($_POST["pass"]) ) 
		{
		//	include("session.php");

			//session_start();
			$retval=true;		
			echo "password matched<br>";
			//$_SESSION["login"]=true;
			break;
		}
		else
		{
			$retval=false;
			echo "password didnt match<br>";
		}
	}
	return $retval;
}

function getVerify($sql){
	//include("session.php");	
	//session_start();
	$conn = mysqli_connect("localhost", "root", "","pcBuilder");
	
	$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	$arr=array();
	$counter=0;
	$cnt =0;
	while($row = mysqli_fetch_assoc($result)) 
	{
		$counter++;
		$arr[]=$row;
	}
	
	//echo "<pre>";print_r($arr);echo " </pre>";
	
	//$pass=MD5($_POST['pword']);
	
	//echo "<pre>";print_r($pass);echo " </pre>";
	
	$retval=false;
	echo "enered verify<br>";
	for($cnt=0;$cnt<$counter;$cnt++)
	{
		
		if($arr[$cnt]["verified"]=="yes" ) 
		{
		//	include("session.php");
			// session_start();
			$retval=true;		
			//$_SESSION["login"]=true;
		}
	}
	return $retval;
}

	
function userTypes($sql){
	//include("session.php");	
	//session_start();
		$conn = mysqli_connect("localhost", "root", "","pcBuilder");
	
	$retval="";
	$result=mysqli_query($conn,$sql);
			 while($row=mysqli_fetch_array($result))
			  {

			  	if($row[1]=="admin")
			  	{
			  		$retval="admin";
			  	}
			  	else if($row[1]=="employee")
			  	{
			  		$retval="employee";
			  	}
			  	else if($row[1]=="user")
			  	{
			  		$retval="user";
			  	}

			  	echo "The user is of ".$row[1];
			  	echo "<br><br>";
			  }
	return $retval;
}


?>

 <pre><?php print_r($GLOBALS)?></pre> 
<html>
<br><br><br>
<input type="button" onclick="location.href='login.html';" value="Go to Login page" >
</html>