<html>
<?php
//include("session.php");
session_start();

$_SESSION["login"]="";



?>
YOU ARE LOGGED OUT <br><br><br>
<a href="login.html">LOG IN</a><br><br>
<a href="index.php">HOMEPAGE</a><br><br>
</html>