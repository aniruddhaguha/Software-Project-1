<script src="js/functions.js"></script>
<link rel="stylesheet" href="css/styles.css">


<?php 
	
	$connect=mysqli_connect("localhost","root","","pcbuilder");
	
	$user_table="select * from user";
	$users=mysqli_query($connect,$user_table);
  $ausers=mysqli_query($connect,$user_table);
	$busers=mysqli_query($connect,$user_table);


	$product_table="select * from product";
	$products=mysqli_query($connect,$product_table);
	
  $unapproved_user="select * from user where verified='no'";
	$unapproved_users=mysqli_query($connect,$unapproved_user);


  //for user approving
  $uuInfo="";
  while($rowx=mysqli_fetch_array($users))
  {
    $uuInfo=$uuInfo."<option value='$rowx[0]'>id=$rowx[0] name=$rowx[3]</option>";
  }

	//for user type
	$user_type_option="";
	while($row2=mysqli_fetch_array($users))
	{
		$user_type_option=$user_type_option."<option>$row2[2]</option>";
	}
  	
?>


<html>
  <body>
    <div class="top">
      <div >
        <div id="wc-txt">
          <p >Welcome<br>Jamie</p>      
        </div>
      </div>
      <div >
        <img  id="logo" src="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_120x44dp.png" alt="shit">
      </div>
      <div >
        <input onclick="adminLogout.php" id="lb" type="button" value="LOGOUT">  
      </div>
    </div>
    
  <!--  THIS IS THE SIDE PANEL  -->
    <div class="sidePanel">
        <a onclick="enableUserAddDelete();">ADD/DELETE USER</a><br>
	      <a onclick="enableModifyingUser();">MODIFY USER</a><br>
        <a onclick="enableApprovingUser();">APPROVE USER</a><br>
	      <a onclick="enableProductAddDelete();">ADD/DELETE USER</a><br>
  		  <a href="something">MODIFY PRODUCTS</a><br>
	      <a onclick="enableUserList();">SEE USER LIST</a><br>
	      <a href="something">SEE PRODUCT LIST</a><br>
	      <a href="something">PENDING REQUEST</a><br>
  		  <a href="something">REPORT</a><br>
      </div>
    </div>
    
  <!--   THIS IS THE MAIN CONTAIN PAGE -->
    <div class="content">
      
<!--     add user content -->

      <div id="add-user">
        <form name="addUser" action="modifytest.php" method="post">
        	<input type="hidden" name="flag" value="add-user">
              
            SELECT USER TYPE :<select name="type">
           <option>admin</option>
           <option>employee</option>
           <option>customer</option>
          </select> <br><br>
            ENTER USER NAME :<input type="text"                 name="name">                 <br><br>
            ENTER USER PASSWORD :<input                         type="text" name="pasword"><br><br>
            ENTER USER EMAIL :<input type="text"
                                     name="email">               <br><br>
            <input type="submit" id="lb" onclick="return validateUserAdding();"                          value="SUBMIT">
        </form>
      </div>
      
<!--       here is the user list -->
      <div id="user-list">
         <table>
           <tr>
             <th>
                USER ID
             </th>
             <th>
               USER TYPE
             </th>
             <th>
               VERIFIED
             </th>
             <th>
               USER NAME
             </th>
             <th>
               PASSWORD
             </th>
             <th>
               EMAIL
             </th>
           </tr>
		  
       <?php 
			   if($users->num_rows>0)
			   {


          // while($row2=mysqli_fetch_array($users))
          //   {
          //     $user_type_option=$user_type_option."<option>$row2[2]</option>";
          //   }

				   while($row=mysqli_fetch_array($ausers))
				   {
					   echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td></tr>";
				   }
			   }
			   else
			   {
				   echo "WHY ISN'T ANYTHING HERE?";
			   }   
			?>
			
           
         </table>
      </div>
      

<!--       HERE IS THE ADD PRODUCT CONTENT -->
	
	<div id="add-product">
		 <form name="addProduct" action="modifytest.php" method="post">
	        	<input type="hidden" name="flag" value="add-product">
	              
	            SELECT CATEGORY :<select name="type" id="theCategory" onchange='populate(this.id,"add-more-content");'>
	           <option>Motherboard</option>
	           <option>Processor</option>
	           <option>GPU</option>
	           <option>RAM</option>
	           <option>HDD</option>
	          </select> <br><br>
	            ENTER PRODUCT NAME :<input type="text"                 name="name">                 <br><br>
	            ENTER PRODUCT RELEASE DATE :<input type="text"                 name="name">                 <br><br>
	            ENTER PRODUCT RATING :<input type="text"                 name="name">                 <br><br>
	            ENTER PRODUCT PRICE :<input type="text"                 name="name">                 <br><br>
	            <div style="display:block" id="add-more-content"><div><br><br>
	            
	            <!-- <input type="submit" id="lb" onclick="return validateUserAdding();"                          value="SUBMIT"> -->
	        </form>
	    </div>


      
<!--       here the approve user list -->
      <div id="approve-user">
      	<form action="modifytest.php" name="approveUser" method="post">
      		<input type="hidden" name="flag" value="approve-user">
          SELECT THE USER TO VERIFY:<select name="approving-user">
            <?php echo $uuInfo;?>
          </select><br>
          <input type="submit" id="lb" name="clickToApprove" value="APPROVE">
      	</form>
      </div>


      <!-- MODIFY USER  -->


      <div id="modify-user">
    <!-- <input type="text" name="test"> -->
        
          <form name="modifyUser" action="modifytest.php" method="post">

          		<input type="hidden" name="flag" value="modify-user">
              
              SELECT THE USER TO MODIFY:
              <select name="target-user" required>
                <?php 
                  if($users->num_rows>0)
                 {
                    while($row=mysqli_fetch_array($busers))
                     {
                       echo "<option value='$row[0]''>$row[0] -- $row[3]</option>";
                     }
                  }
                  else
                  {
                    echo "WHAT HAPPENED?!!";
                  }
                ?>
              </select><br><br>
                SELECT USER TYPE :
                <select name="type">
                  <option>admin</option>
                  <option>employee</option>
                  <option>customer</option>
                </select> <br><br>
                ENTER USER NAME :<input type="text"                 name="name">                 <br><br>
                ENTER USER PASSWORD :<input                         type="text" name="pasword"><br><br>
                ENTER USER EMAIL :<input type="text"
                                         name="email">               <br><br>
                <input type="submit" id="lb" onclick="return validateUserModifying();"                          value="MODIFY">
        </form>
          <!-- <input type="button" id="lb" name="clickToModify" value="MODIFY"> -->
      </div>
      
    </div>
    
    
  <!--   THIS IS THE FOOTER -->
    <div class="footer">
    </div>
  </body>
</html>
