<?php
  include '../../frame-content.php';
?>

  <div class="sidePanel">
        <a href="something">ADD USER</a><br>
        <a href="something">MODIFY USER</a><br>
        <a href="something">APPROVE USER</a><br>
        <a href="something">ADD PRODUCTS</a><br>
        <a href="something">MODIFY PRODUCTS</a><br>
        <a href="something">SEE USER LIST</a><br>
        <a href="something">SEE PRODUCT LIST</a><br>
        <a href="something">PENDING REQUEST</a><br>
        <a href="something">REPORT</a><br>
      </div>

    <div class="content">
      <form action="somethiong" method="post">
        ENTER USER TYPE :    <input type="text"><br><br>
        ENTER USER NAME :    <input type="text"><br><br>
        ENTER USER PASSWORD :    <input type="text"><br><br>
        ENTER USER EMAIL :    <input type="text"><br><br>
        <input type="submit" value="SUBMIT">
      </form>
      
    </div>
          
      </div>