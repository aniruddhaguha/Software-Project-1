<?php 
	
	$connect=mysqli_connect("localhost","root","","pcbuilder");
	$query="select * from user";
	$result=mysqli_query($connect,$query);
	$option="";
	while($row2=mysqli_fetch_array($result))
	{
		$option=$option."<option>$row2[1]</option>";
	}
	
?>
<html>
<select>
	<?php echo $option;?>

</select>
</html>