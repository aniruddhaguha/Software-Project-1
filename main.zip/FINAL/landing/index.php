<?php 
	session_start();
	echo "<pre>";
	print_r($GLOBALS);
	echo "</pre>";
?>	
<style>

	.items{

	  align-items: center;
	  text-align: center;
      display:grid;
      grid-template-columns: 25% 25% 25% 25%;
      /*grid-template-rows: : 600px 600px;*/
	  /*
      grid-column-gap:1em;
      grid-row-gap:1em;
      */
      height:80%;
      overflow:auto;
      grid-gap:1em;
      padding:2em;
	 
    }

    .items > div{
      background:#83bfef;
      padding:1em;
    }
   .items > div:nth-child(odd){
      background:#cce0c7;
    }
	.footer{
		align:center;
		background-color:yellow;
		color:red;
		
	}
	#boxes{
		height:400px;
		width: 300px;
		overflow: auto;
	}
	  .items img{
    	height:220px;
     width:200px;

    	/*background-color: white;*/
    }
    .product{
		font-family:fantasy;
		font-style:bold;
		font-size: 15px;
		text-align: center;
		color:#054687;
	}
</style>






<html>
	<head>
		<title>BOB THE PC BUILDER</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/item-boxing.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
	</head>
	<div class="topnav">
		
		  <input type="text" placeholder="Search..">`
	</div>

	<body class="homepage">

		<!-- Header -->
		<div id="header">
			<div class="container">
				
				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">BOB THE PC BUILDER</a></h1>
				</div>
				
				<!-- Nav -->
				<nav id="nav">
					<ul>	
						<link rel="stylesheet" href="css/custom.css" />
			
						    <button class="dropbtn" onclick="window.location.href='index.php'"">HOME</button>

							<div class="dropdown">
						  <button class="dropbtn">COMPONENTS</button>
						  <div class="dropdown-content">
						    <a href="motherboard.php">MOTHERBOARD</a>
						    <a href="processor.php">PROCESSOR</a>
						    <a href="gpu.php">GRAPHICS CARD</a>
						    <a href="ram.php">RAM</a>
						    <a href="hdd.php">HARD DISK</a>
						  </div>
						</div>
							
						  	 <button class="dropbtn" onclick="window.location.href='about.html'"">ABOUT</button>
							

						</div>

						<!-- <li class="active"><a href="index.html">Homepage</a></li>
						<li><a href="twocolumn1.html">Left Sidebar</a></li>
						<li><a href="twocolumn2.html">Right Sidebar</a></li>
						<li><a href="#">Left Sidebar</a></li>
						<li><a href="#">Left Sidebar</a></li>
						<li><a href="#">No Sidebar</a></li> -->
					</ul>
				</nav>

			</div>
		</div>
		<!-- Header -->

		<!-- Banner -->
		
		<div id="banner">
			<div class="container">


			</div>
		</div>
		<!-- /Banner -->
		
		<!-- Main -->
		<div id="main">


		    <div class="items product">
		<!-- 		<div id="boxes">
					NAME
					<br>
					PRICEasjbjk><br><br><br><br><br><br><br><br><br><br>
					HSAME
					<br>
					STOCK STATE
				</div><div id="boxes">
					NAME
					<br>
					PRICE
					<br>
					STOCK STATE
				</div><div id="boxes">
					NAME
					<br>
					PRICE
					<br>
					STOCK STATE
				</div><div id="boxes">
					NAME
					<br>
					PRICE
					<br>
					STOCK STATE
				</div> -->
					<?php 
			$connect=mysqli_connect("localhost","root","","pcbuilder");
			$query="select * from product";
			$result=mysqli_query($connect,$query);
			// echo "<div class='items'> ";
			 while($row=mysqli_fetch_array($result))
			  {
			  	/*echo '<div p_id="$row[0]"> <img style="height:30px;width:40px;" <img src="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_120x44dp.png" alt="test"><br>';
			    echo "ID=$row[0]</div><br>";*/
			    // echo "<div p_id='$row[0]'> <img src='$row[5]' alt='$row[5]><br>";
			    // echo "$row[2]<br>PRICE:$row[3]<br></div>";
			    echo "<div id='boxes'> <img src='$row[5]' alt='test'><br>";
			    echo "ITEM NAME: $row[2]<br>PRICE: $row[3]<br>VENDOR: $row[6]<br>RATING: $row[4]";
			    echo"</div>";
			  }
			  // echo "</div>";

		?>
		    </div>





		<!-- 	<div id="portfolio" class="container">
				<div class="row">
					<section class="3u">
						<header>
							<h2>Maecenas luctus</h2>
						</header>
						<a href="#" class="image full"><img src="images/p1.jpg" alt=""></a>
						<p>Pellentesque viverra  enim.Tristique ante ut risus. Quisque dictum. Integer nisl risus, sagittis convallis, rutrum id, elementum.</p>
						<a href="#" class="button">Read More</a>
					</section>
					<section class="3u">
						<header>
							<h2>Leven 4GB DDR4 2400 BUS Desktop RAM</h2>
						</header>
						<a href="#" class="image full"><img src="images/p2.jpg" alt=""></a>
						<p>Pellentesque viverra  enim.Tristique ante ut risus. Quisque dictum. Integer nisl risus, sagittis convallis, rutrum id, elementum.</p>
						<a href="#" class="button">Read More</a>
					</section>
					<section class="3u">
						<header>
							<h2>Gigabyte GeForce GTX 1050 Ti Windforce OC 4GB GDDR5 Graphics Card #GV-N105TWF2OC-4GD</h2>
						</header>
						<a href="#" class="image full"><img src="images/p3.jpg" alt=""></a>
						<p>Pellentesque viverra  enim.Tristique ante ut risus. Quisque dictum. Integer nisl risus, sagittis convallis, rutrum id, elementum.</p>
						<a href="#" class="button">Read More</a>
					</section>
					<section class="3u">
						<header>
							<h2>Intel Core i7 3820 3.6GHz 3rd Gen. Processor</h2>
						</header>
						<a href="#" class="image full"><img src="images/p4.jpg" alt=""></a>
						<p>Pellentesque viverra  enim.Tristique ante ut risus. Quisque dictum. Integer nisl risus, sagittis convallis, rutrum id, elementum.</p>
						<a href="#" class="button">Read More</a>
					</section>
				</div>
			</div> -->
			
			<!-- Welcome -->		
			<!-- <div id="welcome" class="container">
				<div class="divider"></div>
				<div class="row">
					
				</div> -->
			</div>
			<!-- /Welcome -->
			
		</div>
		<!-- /Main -->		
		
		<!-- Footer -->

		<div id="footer">
			<div >
				<section>
					<header>
						<h2>New Available!</h2>
						<span class="byline">Checout the latest computer components available in market</span>
					</header>
					<div class="row">
						<section class="4u">
							<a href="#" class="image full"><img src="images/mp1.jpg" alt=""></a>
						</section>
						<section class="4u">
							<a href="#" class="image full"><img src="images/p12.jpg" alt=""></a>
						</section>
						<section class="4u">
							<a href="#" class="image full"><img src="images/p13.jpg" alt=""></a>
						</section>
					</div>
					<a href="#" class="button">Check Now!</a>
				</section>
			</div>
		</div>


		<!-- LOG IN/LOG OUT -->
		<div>
		<script type="text/javascript">
			
			/*{
				var a=document.getElementById("loginStatus").value;
				if(a=="LOG IN")
				{
					$(location).attr('href', 'login.html');
				}
				else
				{
					var xmlhttp = getXmlHttp();
				    var xmlhttp = new XMLHttpRequest();
				    xmlhttp.open('GET','./destroy_session.php', true);
				    xmlhttp.onreadystatechange=function(){
				       if (xmlhttp.readyState == 4){
				          if(xmlhttp.status == 200){
				             alert(xmlhttp.responseText);
				         }
				       }
				    };
				    xmlhttp.send(null);
				    a="LOG IN";
				}
			}*/

		</script>
			<button id="loginStatus" class='button3'>
			<?php
				if(isset($_SESSION['login']))
				 {
				 	if($_SESSION['login']==true)
				 	{
						echo '<a style="color: white; text-decoration:none;" href="logout.php">LOG OUT</a>';
				 	}
				 	else
				 	{
				  		echo '<a style="color: white; text-decoration:none;" href="login.html">LOG IN</a>';
				 	}
				 }
				 else
				 {
				 	echo '<a style="color: white; text-decoration:none;"  href="login.html">LOG IN</a>';
				 }
			?>
		 </button>
			
		</div>
		<!-- /Footer -->

	</body>
</html>