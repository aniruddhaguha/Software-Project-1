
<!-- THS IS THE JS FUNCTION PART -->


//LINK CLICK TO DISPLAY DIFFERENT CONTENTS

function enableUserAddDelete(){
  document.getElementById("add-user").style.display="inline-block";
  document.getElementById("user-list").style.display="none";
  document.getElementById("approve-user").style.display="none";
  document.getElementById("modify-user").style.display="none";
  document.getElementById("add-product").style.display="none";
}

function enableUserList(){
  document.getElementById("add-user").style.display="none";
  document.getElementById("user-list").style.display="inline-block";
  document.getElementById("approve-user").style.display="none";
  document.getElementById("modify-user").style.display="none";
  document.getElementById("add-product").style.display="none";
}

function enableApprovingUser(){
  document.getElementById("add-user").style.display="none";
  document.getElementById("user-list").style.display="none";  
  document.getElementById("approve-user").style.display="inline-block";
  document.getElementById("modify-user").style.display="none";
  document.getElementById("add-product").style.display="none";
}

function enableModifyingUser(){
  alert("called to modify");
  document.getElementById("add-user").style.display="none";
  document.getElementById("user-list").style.display="none";  
  document.getElementById("approve-user").style.display="none";
  document.getElementById("modify-user").style.display="inline-block";
  document.getElementById("add-product").style.display="none";
}
function enableProductAddDelete(){
  document.getElementById("add-user").style.display="none";
  document.getElementById("user-list").style.display="none";  
  document.getElementById("approve-user").style.display="none";
  document.getElementById("modify-user").style.display="none";
  document.getElementById("add-product").style.display="inline-block";  
}

//VALIDATION PART


function validateUserAdding(){
  console.log("hey");

  flag=true;
  var a=document.forms["addUser"].type.value.length;
  var b=document.forms["addUser"].name.value.length;
  var c=document.forms["addUser"].pasword.value.length;
  var d=document.forms["addUser"].email.value.length;
  //alert(document.mfm.fileToUpload.value);
  //alert(document.mfm.fileToUpload.value);
    if((a ==0) ||(b==0)||(c==0)||(d==0))
  {
    alert("Can't keep the fields empty");
    flag=false;
  }

  else
  {
    flag=true;
  }
  return flag;
}

function validateUserModifying(){
  console.log("hey");

  flag=true;
  var a=document.forms["modifyUser"].type.value.length;
  var b=document.forms["modifyUser"].name.value.length;
  var c=document.forms["modifyUser"].pasword.value.length;
  var d=document.forms["modifyUser"].email.value.length;
  //alert(document.mfm.fileToUpload.value);
  //alert(document.mfm.fileToUpload.value);
    if((a ==0) ||(b==0)||(c==0)||(d==0))
  {
    alert("Can't keep the fields empty");
    flag=false;
  }

  else
  {
    flag=true;
  }
  return flag;
}


function populate(s1,s2){

  var s1 = document.getElementById(s1);
  alert(s1.value);
  var s2 = document.getElementById(s2);
  if(s1.value=="Motherboard")
  {
    // s2.innerHTML = '<input type="text">';
    s2.innerHTML='FRONT SIDE BUS:<input type="text" name="frontsidebus" placeholder="eg:800MHz"><br><br>USB VERSION: <input type="text" name="usb" placeholder="eg:3.1"> <br><br><input type="submit" id="lb" onclick="return validateUserAdding();"value="SUBMIT">';
  }

}