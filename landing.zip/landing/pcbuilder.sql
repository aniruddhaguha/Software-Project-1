-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2018 at 06:13 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pcbuilder`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_pass` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_pass`, `email`) VALUES
(1, 'basher', '6991', 'basheroo@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `p_id` int(6) NOT NULL,
  `p_type` varchar(50) NOT NULL,
  `p_name` varchar(60) NOT NULL,
  `p_price` float NOT NULL,
  `p_rating` float NOT NULL,
  `p_image` varchar(200) NOT NULL,
  `p_vendor` varchar(50) NOT NULL,
  `p_reference` int(8) NOT NULL,
  `buy_link` varchar(200) NOT NULL,
  `p_desc` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `p_type`, `p_name`, `p_price`, `p_rating`, `p_image`, `p_vendor`, `p_reference`, `buy_link`, `p_desc`) VALUES
(0, 'CPU', 'AMD RYZEN THREADRIPPER', 28000, 9.4, 'https://www.amd.com/system/files/138886-threadripper-2-pib-1260x709.png', 'AMD', 3, 'sadgasd', 'VERY GOOD'),
(1, 'Motherboard', 'Gigabyte 760fx', 9500, 9.2, 'https://static.gigabyte.com/Product/2/6225/2017021515553259_mm.png', 'Gigabyte', 2, 'gigabyte.com', 'nnoy sndkjfbash'),
(2, 'CPU', 'AMD RYZEN THREADRIPPER', 28000, 9.4, 'https://www.amd.com/system/files/138886-threadripper-2-pib-1260x709.png', 'AMD', 3, 'sadgasd', 'VERY GOOD'),
(3, 'Motherboard', 'Gigabyte 260fx', 6500, 7.6, '', '', 0, '', 'RELEASED in 2014 and very good too'),
(4, 'CPU', 'AMD RYZEN THREADRIPPER', 28000, 9.4, 'https://www.amd.com/system/files/138886-threadripper-2-pib-1260x709.png', 'AMD', 3, 'sadgasd', 'VERY GOOD'),
(5, 'CPU', 'AMD RYZEN THREADRIPPER', 28000, 9.4, 'https://www.amd.com/system/files/138886-threadripper-2-pib-1260x709.png', 'AMD', 3, 'sadgasd', 'VERY GOOD'),
(6, 'CPU', 'AMD RYZEN THREADRIPPER', 28000, 9.4, 'https://www.amd.com/system/files/138886-threadripper-2-pib-1260x709.png', 'AMD', 3, 'sadgasd', 'VERY GOOD'),
(7, 'CPU', 'AMD RYZEN THREADRIPPER', 28000, 9.4, 'https://www.amd.com/system/files/138886-threadripper-2-pib-1260x709.png', 'AMD', 3, 'sadgasd', 'VERY GOOD'),
(8, 'CPU', 'AMD RYZEN THREADRIPPER', 28000, 9.4, 'https://www.amd.com/system/files/138886-threadripper-2-pib-1260x709.png', 'AMD', 3, 'sadgasd', 'VERY GOOD');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(5) NOT NULL,
  `user_type` varchar(15) NOT NULL,
  `verified` varchar(3) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_type`, `verified`, `user_name`, `user_pass`, `email`) VALUES
(1, 'admin', 'yes', 'asd', 'asd', 'x@gmail.com'),
(4, 'admin', 'yes', 'hridoyBoss', '1234', 'hridoy@hridoy.com'),
(5, 'employee', 'yes', 'mustafa', '1996', 'mustafabasher@gmail.com'),
(6, 'user', 'no', 'james', '1234', 'ani@aiub.com'),
(7, 'admin', '', 'alamin', '123', 'asd'),
(8, 'user', 'yes', 'aniruddha', '1234', 'a@aiub.com'),
(9, 'admin', '', 'asd', 'saf', 'asf'),
(10, 'admin', '', 'asd', 'faszxc', 'asdasfas'),
(11, 'admin', '', 'asf', 'asd', 'safda'),
(12, 'admin', '', 'asf', 'sdfasd', 'sdgasd'),
(13, 'admin', '', 'asfd', 'asfd', 'asvfc'),
(14, 'admin', '', 'asfd', 'asfd', 'asvfc'),
(15, 'employee', '', 'johny', '4321', 'johny@gmail.com'),
(16, 'admin', '', 'asfasf', 'asfd', 'agsasgasf'),
(17, 'admin', 'no', 'asfas', 'zxv', 'asdfasf'),
(18, 'user', 'no', 'asdnjas', '1234', 'anasi@aiub.com'),
(19, 'customer', 'yes', 'Alamin', '1234', 'alamin@aiub.edu');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `user_id` varchar(100) NOT NULL,
  `product_id` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=hp8;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`user_id`, `product_id`) VALUES
('0', 0),
('0', 0),
('\"anirud', 0),
('\"aniruddha\"', 0),
('aniruddha', 0),
('aniruddha', 3),
('aniruddha', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
