<html>
<?php
//include("session.php");
session_start();

$_SESSION["adminLogin"]="";
$_SESSION["userLogin"]="";

header ("Location: ./login.html");

?>

</html>