<html>
  
  <head>

      <link rel="stylesheet" href="css/framework.css">
  </head>
  

  <body>
    <div class="top">
      <div >
        <div id="wc-txt">
          <p >Welcome<br>Jamie</p>      
        </div>
      </div>
      <div >
        <img  id="logo" src="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_120x44dp.png" alt="">
      </div>
      <div >
        <input id="lb" type="button" value="LOGOUT">  
      </div>
    </div>
    
  <!--  THIS IS THE SIDE PANEL  -->
    <div class="sidePanel">
      <a href="something">OPTION 1</a><br>
      <a href="something">OPTION 2</a><br>
      <a href="something">OPTION 3</a><br>
      <a href="something">OPTION 4</a><br>
    </div>
    
  <!--   THIS IS THE MAIN CONTAIN PAGE -->
    <div class="content">
      
      
    </div>
    
    
  <!--   THIS IS THE FOOTER -->
    <div class="footer">
    </div>
  </body>
</html>