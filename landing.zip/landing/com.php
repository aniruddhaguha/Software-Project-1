<?php	
	include('p1p.html') ;
	include('p2p.html') ;
	?>
	<html>
		<div class="sidePanel">
	      <a href="something">ADD USER</a><br>
	      <a href="something">MODIFY USER</a><br>
	      <a href="something">APPROVE USER</a><br>
  		  <a href="something">ADD PRODUCTS</a><br>
  		  <a href="something">MODIFY PRODUCTS</a><br>
	      <a href="something">SEE USER LIST</a><br>
	      <a href="something">SEE PRODUCT LIST</a><br>
	      <a href="something">PENDING REQUEST</a><br>
  		  <a href="something">REPORT</a><br>
    	</div>

		<div class="content">
      		
    	</div>
	</html>