<?php
      echo "<div id='main'>";
        echo "<div class='fof'>";

  if(isset($_REQUEST["flag"]) && strlen($_REQUEST["flag"])>0 ){
        if($_REQUEST["flag"])=="%27approveuser%27")
        {
              echo "<h1>USER SUCCESFULLY APPROVED</h1>";
        }
        else if($_REQUEST["flag"])=='%adduser%27'){
        echo "<h1>USER SUCCESFULLY ADDED</h1>";
      }
        
      }
    
    else
    {
      echo "didn't enter";
    }
            echo "</div>";
            echo "</div>";
?>