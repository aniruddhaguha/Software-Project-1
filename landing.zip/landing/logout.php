<?php
//include("session.php");
session_start();

$_SESSION["userLogin"]="";
$_SESSION["adminLogin"]="";

header ("Location: ./login.html");
?>