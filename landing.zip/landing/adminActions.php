
<?php 


	 echo "<div id='main'>";
        echo "<div class='fof'><h1>";
	
	$connect=mysqli_connect("localhost","root","","pcbuilder");

	if(mysqli_connect_errno())
	// if(1==2)
	{
		echo "FAILED TO CONNECT TO DATABASE".mysqli_connect_error();
	}
	else
	{
		if($_POST["flag"]=="approve-user")
		{
			$query="UPDATE user SET  verified = 'yes' WHERE user_id =".$_POST["approving-user"];
			mysqli_query($connect,$query);
			// header("location: messages/message.php?flag='approveuser'");
			echo "USER UPDATED";
		}
		else if($_POST["flag"]=="signup")
		{
			$query="INSERT INTO user (user_type, user_name, user_pass, email,verified) VALUES ('user', '$_POST[username]', '$_POST[pass]','$_POST[email]', 'no')";
			if(mysqli_query($connect,$query))
			{

			//header("location: messages/message.php?flag='adduser'");
				echo"YOU ARE SIGNED UP, WAIT FOR THE ADMIN TO VERIFY";
			}
			else
			{
			echo "SIGN UP FAILED";	
			//header("location:messages/message.php?flag='error'");
			}
		}


		else if($_POST["flag"]=="modify-user")
		{
			/*$query="UPDATE user SET  user_name =".$_POST["name"].", user_type=".$_POST["type"].", user_pass=".$_POST["pasword"].",email=".$_POST["email"]."  WHERE user_id =".$_POST["target-user"];
			$query='update user set user_name='.$_POST["name"].', user_type='.$_POST["type"].',user_pass='.$_POST["pasword"].',email='.$_POST["email"].' where user_id='.$_POST["target-user"];*/
			$query="UPDATE user SET user_name='$_POST[name]', user_type='$_POST[type]',user_pass='$_POST[pasword]', email='$_POST[email]' WHERE user_id=".$_POST['target-user'];
			if(mysqli_query($connect,$query))
			{
				echo "USER modified";
				
			//header("location:messages/message.php?flag='modifyuser'");
			}
			else
			{
				echo "USER MODIFY ERROR";
			//header("location:messages/message.php?flag='error'");
			}

		}


		else if($_POST["flag"]=="add-user")
		{
			$query="INSERT INTO user (user_type, user_name, user_pass, email,verified) VALUES ('$_POST[type]', '$_POST[name]', '$_POST[pasword]','$_POST[email]', 'no')";
			if(mysqli_query($connect,$query))
			{

			//header("location: messages/message.php?flag='adduser'");
				echo"SUCCESSFULLY ADDED";
			}
			else
			{
			echo "USER ADDING FAILED";	
			//header("location:messages/message.php?flag='error'");
			}

		}


		else
		{
			//header("location:messages/message.php?flag='error'");
			echo "THERE MUST BE A PROBLEM";
		}
	}

    echo "</h1></div>";
    echo "</div>";


?>


<style>
*{
    transition: all 0.6s;
}

html {
    height: 100%;
}

body{
    font-family: 'Lato', sans-serif;
    color: #888;
    margin: 0;
}

#main{
    display: table;
    width: 100%;
    height: 100vh;
    text-align: center;
}

.fof{
    display: table-cell;
    vertical-align: middle;
}

.fof h1{
    font-size: 50px;
    display: inline-block;
    padding-right: 12px;
    animation: type .5s alternate infinite;
}

@keyframes type{
    from{box-shadow: inset -3px 0px 0px #888;}
    to{box-shadow: inset -3px 0px 0px transparent;}
}

</style>
