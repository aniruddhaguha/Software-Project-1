<?php
session_start();
 if(isset($_SESSION['login']))
 {
 	if($_SESSION['login']==true)
 	{
 		echo "Hoice vaia!";
 	}
 	else
 	{
 		echo "hoy nai vai";
 	}
 }
 else
 {
 	echo "Kisu khuija pai nai";
 }
?>