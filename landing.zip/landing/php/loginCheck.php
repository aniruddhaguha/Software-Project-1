<html>
<title>Login</title>
<body>
  <?php
  //include('session.php') ;
  session_start();
  $usr = "admin@gmail.com";
  $psw = "1234";
  $password = $_POST["pass"];
  $username = $_POST["email"];
  //$usr == $username && $psw == $password
   if ($_SESSION['login']==true || ($username=="admin@gmail.com" && $password=="1234")) {
    echo "password accepted";
    $_SESSION['login']=true;
    echo 'console.log('. $_SESSION['login'] .')';
  }
    else {
      echo "incorrect login";
    }
    

     if(isset($password) && isset($username))
     {
        if($usr==$username && $psw==$password)
        {

          echo "<p>hello<p>";

        }
        else
        {
          echo "<p>shit<P>";
        }
        
     }
     else
     {
      echo "INPUt";
     }
?>
  </body>
</html>