<?php
  session_start();
  if(isset($_SESSION['adminLogin']) ) { 
    echo "hurray";
    if(strlen($_SESSION["adminLogin"])==0)
    {
      echo "Lenght 0";
    }
    else if(strlen($_SESSION["adminLogin"])<6)
    {
      echo "Lenght LESS THAN 6";
    }
    else
    {
      echo "Lenght more than 6";
    }
  } 
  else
  {
    echo "shit";
  }
  echo "<pre>";
  echo print_r($GLOBALS);
  echo "</pre>";
  ?>
