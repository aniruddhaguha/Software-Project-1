<script src="js/functions.js"></script>
<link rel="stylesheet" href="css/styles.css">


<?php 
  session_start();
  if(!isset($_SESSION['adminLogin']) || strlen($_SESSION["adminLogin"])==0 ) { 
    header("location:./login.html");
  } 
  // echo "<pre>";
  // echo print_r($GLOBALS);
  // echo "</pre>";
	$connect=mysqli_connect("localhost","root","","pcbuilder");
	
  $user_table="select * from user";
  $verifyquery="select * from user where verified <>'yes'";

	$users=mysqli_query($connect,$user_table);
  $ausers=mysqli_query($connect,$user_table);
	$busers=mysqli_query($connect,$user_table);

  $verified=mysqli_query($connect,$verifyquery);

  $product_table="select * from product";

  $products=mysqli_query($connect,$user_table);


	$product_table="select * from product";
	$products=mysqli_query($connect,$product_table);
	
  $unapproved_user="select * from user where verified='no'";
	$unapproved_users=mysqli_query($connect,$unapproved_user);


  // //for user approving
  // $uuInfo="";
  // while($rowx=mysqli_fetch_array($verified))
  // {
  //   $uuInfo=$uuInfo."<option>id=$rowx[0] name=$rowx[3]</option>";
  // }

	//for user type
	$user_type_option="";
	while($row2=mysqli_fetch_array($users))
	{
		$user_type_option=$user_type_option."<option>$row2[2]</option>";
	}
  	
?>



<html>
  <body >
    <div class="top">
      <div >
        <div id="wc-txt">
          <p >Welcome<br><?php echo $_SESSION["adminLogin"]?></p>      
        </div>
      </div>
      <div >
        <img  id="logo" src="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_120x44dp.png" alt="shit">
      </div>
      <div >
        <input onclick="window.location.href='adminLogout.php'" id="lb" type="button" value="LOGOUT">  
      </div>
    </div>
    
 <!--  THIS IS THE SIDE PANEL  -->
    <div class="sidePanel">
        <a onclick="enableUserAddDelete();">ADD/DELETE USER</a><br>
        <a onclick="enableModifyingUser();">MODIFY USER</a><br>
        <a onclick="enableApprovingUser();">APPROVE USER</a><br>
        <a onclick="enableProductAddDelete();">ADD/DELETE PRODUCT</a><br>
        <a onclick="enableModifyingProduct();">MODIFY PRODUCTS</a><br>
        <a onclick="enableUserList();">SEE USER LIST</a><br>
        <a onclick="enableProductList();">SEE PRODUCT LIST</a><br>
        <a href="something">PENDING REQUEST</a><br>
        <a href="something">REPORT</a><br>
      </div>
    
  <!--   THIS IS THE MAIN CONTAIN PAGE -->
    <div class="content">
      
      
<!--     add user content -->
      <div id="add-user">
        <form name="addUser" action="adminActions.php" method="post">
              <input type="hidden" name="flag" value="add-user">
            SELECT USER TYPE :<select name="type">
           <option>admin</option>
           <option>employee</option>
           <option>customer</option>
          </select> <br><br>
            ENTER USER NAME :<input type="text"                 name="name">                 <br><br>
            ENTER USER PASSWORD :<input                         type="text" name="pasword"><br><br>
            ENTER USER EMAIL :<input type="text"
                                     name="email">               <br><br>
            <input type="submit" id="lb" onclick="return validateUserAdding();"                          value="SUBMIT">
        </form>
      </div>
      
<!--       here is the user list -->
      <div id="user-list">
         <table>
           <tr>
             <th>
                USER ID
             </th>
             <th>
               USER TYPE
             </th>
             <th>
               VERIFIED
             </th>
             <th>
               USER NAME
             </th>
             <th>
               PASSWORD
             </th>
             <th>
               EMAIL
             </th>
           </tr>
		  
       <?php 
			   if($users->num_rows>0)
			   {


          // while($row2=mysqli_fetch_array($users))
          //   {
          //     $user_type_option=$user_type_option."<option>$row2[2]</option>";
          //   }

				   while($row=mysqli_fetch_array($ausers))
				   {
					   echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td></tr>";
				   }
			   }
			   else
			   {
				   echo "WHY ISN'T ANYTHING HERE?";
			   }   
			?>
			
           
         </table>
      </div>
      
      
<!--       here the approve user list -->
      <div id="approve-user">

          <form action="adminActions.php" name="approveUser" method="post">
          <input type="hidden" name="flag" value="approve-user">
          SELECT THE USER TO VERIFY:<select name="approving-user">
            <?php 
            //for user approving
              
              while($rowx=mysqli_fetch_array($verified))
              {
                echo "<option>$rowx[0]</option>";
              }
            ?>
          </select><br>
          <input type="submit" onclick="return validateUserApproving();" id="lb" name="clickToApprove" value="APPROVE">
        </form>
      </div>

      

  <!-- MODIFYING PRODUCTS CONTENT -->


      <div id="modify-product">
          <form name="modifyProduct" action="adminActions.php" method="post">
              SELECT THE PRODUCT TO MODIFY:
              <select name="target-product" required>
                <?php 
                  if($products->num_rows>0)
                 {
                    mysqli_data_seek($products,0);
                    while($row=mysqli_fetch_array($products))
                     {
                       echo "<option value='$row[0]''>$row[1] -- $row[2]</option>";
                     }
                  }
                  else
                  {
                    echo "WHAT HAPPENED?!!";
                  }
                   mysqli_data_seek($products,0);
                ?>
            </select><br><br>

              SELECT CATEGORY :<select name="type" id="theCategory" onchange='populate(this.id,"add-more-content");'>
             <option>Motherboard</option>
             <option>Processor</option>
             <option>GPU</option>
             <option>RAM</option>
             <option>HDD</option>
            </select> <br><br>
              ENTER PRODUCT NAME :<input type="text"                 name="name">                 <br><br>
              ENTER PRODUCT RATING :<input type="text"                 name="name">                 <br><br>
              ENTER PRODUCT PRICE :<input type="text"                 name="name">                 <br><br>
              ENTER PRODUCT IMAGE NAME :<input type="text"                 name="name">                 <br><br>
              ENTER PRODUCT VENDOR :<input type="text"                 name="name">                 <br><br>
              ENTER BUY LINK :<input type="text"                 name="name">
                               <br><br>
              ENTER REFERENCE NUMBER :<input type="text"                 name="name">                 <br><br>
              ENTER PRODUCT DESCRIPTION :<input type="text"                 name="name">                 <br><br>
              <div style="display:block" id="add-more-content"><div><br><br>


        </form>
          <!-- <input type="button" id="lb" name="clickToModify" value="MODIFY"> -->
      </div>


      <!-- MODIFY USER  -->
      <div id="modify-user">
          <form name="modifyUser" action="adminActions.php" method="post">
              SELECT THE USER TO MODIFY:
              <select name="target-user" required>
                <?php 
                  if($users->num_rows>0)
                 {
                    while($row=mysqli_fetch_array($busers))
                     {
                       echo "<option value='$row[0]''>$row[0] -- $row[3]</option>";
                     }
                  }
                  else
                  {
                    echo "WHAT HAPPENED?!!";
                  }
                ?>
              </select><br><br>
                SELECT USER TYPE :
                <select name="type">
                  <option>admin</option>
                  <option>employee</option>
                  <option>customer</option>
                </select> <br><br>
                ENTER USER NAME :<input type="text"                 name="name">                 <br><br>
                ENTER USER PASSWORD :<input                         type="text" name="pasword"><br><br>
                ENTER USER EMAIL :<input type="text"
                                         name="email">               <br><br>
                <input type="submit" id="lb" onclick="return validateUserModifying();"                          value="MODIFY">
        </form>
          <!-- <input type="button" id="lb" name="clickToModify" value="MODIFY"> -->
      </div>



  <!--       HERE IS THE ADD PRODUCT CONTENT -->
  
  <div id="add-product">
     <form name="addProduct" action="adminActions.php" method="post">
            <input type="hidden" name="flag" value="add-product">
                
              SELECT CATEGORY :<select name="type" id="theCategory" onchange='populate(this.id,"add-more-content");'>
             <option>Motherboard</option>
             <option>Processor</option>
             <option>GPU</option>
             <option>RAM</option>
             <option>HDD</option>
            </select> <br><br>
              ENTER PRODUCT NAME :<input type="text"                 name="name">                 <br><br>
              ENTER PRODUCT RELEASE DATE :<input type="text"                 name="name">                 <br><br>
              ENTER PRODUCT RATING :<input type="text"                 name="name">                 <br><br>
              ENTER PRODUCT PRICE :<input type="text"                 name="name">                 <br><br>
              <div style="display:block" id="add-more-content"><div><br><br>
              
              <!-- <input type="submit" id="lb" onclick="return validateUserAdding();"                          value="SUBMIT"> -->
          </form>
      </div>



<!-- HERE IS THE PRODUCT LIST -->

      <div id="product-list">
         <table>
           <tr>
             <th>
                PRODUCT ID
             </th>
             <th>
               PRODUCT TYPE
             </th>
             <th>
               NAME
             </th>
             <th>
               PRICE
             </th>
             <th>
               RATING
             </th>
             <th>
               IMAGE NAME
             <th>
               VENDOR
             <th>
               REFERENCE DB
             <th>
               BUY LINK
             <th>
               DESCRIPTION
             </th>
           </tr>
      
       <?php 
        mysqli_data_seek($products,0);
         if($users->num_rows>0)
         {

           while($row=mysqli_fetch_array($products))
           {
             echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td></tr>";
           }
         }
         else
         {
           echo "WHY ISN'T ANYTHING HERE?";
         }   
      ?>
      
           
         </table>
      </div>

<div>
</div>

    


      
    </div>
    
    
  <!--   THIS IS THE FOOTER -->
    <div class="footer">
    </div>
  </body>
</html>


