
<?php
session_start();
require("db_rw.php");
	echo "hey";
	if($_SESSION["userLogin"]<>"")
	{
		if(isset($_REQUEST["pro_id"]) && strlen($_REQUEST["pro_id"])>0 ){
			if(isset($_REQUEST["user_id"]) && strlen($_REQUEST["user_id"])>0 ){
				//$sql="select * from wishlist where pro_id='".$_REQUEST["pro_id"]."'";
				

				$sql="INSERT INTO `WISHLIST` (`user_id`, `product_id`) VALUES ('".$_REQUEST["user_id"]."', ".$_REQUEST["pro_id"].")";
				$connect=mysqli_connect("localhost","root","","pcbuilder");
				$result=mysqli_query($connect,$sql);
				echo "ADDED TO WISHLIST";
			
				//$sql="INSERT INTO `wishlist` (`id`, `cpname`, `cpunituser_id`, `units`) VALUES (NULL, '".$_REQUEST["pro_id"]."', '200', '1')";
				
			}
		}
		else
		{
			echo "didn't enter";
		}
	}
	else
	{
		echo "you have to be logged in, in order to view your wishlist";
	}
	//nothing
	

?>
