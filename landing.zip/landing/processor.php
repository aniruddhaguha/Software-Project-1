php
<!--
	Royale by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>BOB THE PC BUILDER</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
	</head>
	<div class="topnav">
		
		  <input type="text" placeholder="Search..">
	</div>

	<body class="homepage">

		<!-- Header -->
		<div id="header">
			<div class="container">
				
				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">BOB THE PC BUILDER</a></h1>
				</div>
				
				<!-- Nav -->
				<nav id="nav">
					<ul>	
						<link rel="stylesheet" href="css/custom.css" />
			
						    <button class="dropbtn" onclick="window.location.href='index.php'"">HOME</button>

							<div class="dropdown">
						  <button class="dropbtn">COMPONENTS</button>
						  <div class="dropdown-content">
						    <a href="motherboard.php">MOTHERBOARD</a>
						    <a href="processor.php">PROCESSOR</a>
						    <a href="gpu.php">GRAPHICS CARD</a>
						    <a href="ram.php">RAM</a>
						    <a href="hdd.php">HARD DISK</a>
						  </div>
						</div>
							 <button class="dropbtn" onclick="window.location.href='about.html'"">ABOUT</button>
							 
							

						</div>

						<!-- <li class="active"><a href="index.html">Homepage</a></li>
						<li><a href="twocolumn1.html">Left Sidebar</a></li>
						<li><a href="twocolumn2.html">Right Sidebar</a></li>
						<li><a href="#">Left Sidebar</a></li>
						<li><a href="#">Left Sidebar</a></li>
						<li><a href="#">No Sidebar</a></li> -->
					</ul>
				</nav>

			</div>
		</div>
		<!-- Header -->

		<!-- Banner -->
		
		<div id="banner">
			<div class="container">


			</div>
		</div>
		<!-- /Banner -->
		
		<!-- Main -->
		<div id="main">
			<div id="portfolio" class="container">
				<div class="row">
					<section class="3u">
						<header>
							<h2>Intel Kaby Lake Core i3 7100 3.90GHz 3MB Cache LGA1151 7th Gen.Processor</h2>
						</header>
						<a href="#" class="image full"><img src="images/mp2.jpg" alt=""></a>
						<p>Price Tk 16,170</p>
						<a href="#" class="button">Details</a>
						<a href="#" class="button">Compare</a>
					</section>
					<section class="3u">
						<header>
							<h2>LAMD Ryzen 3 1200 3.1-3.4 GHz 4-Core 8MB Cache 65W AM4 Processor</h2>
						</header>
						<a href="#" class="image full"><img src="images/mp3.jpg" alt=""></a>
						<p>Price Tk 10,000</p>
						<a href="#" class="button">Details</a>
						<a href="#" class="button">Compare</a>
					</section>
					<section class="3u">
						<header>
							<h2>Intel Kaby Lake Core i5 7400 3.00-3.50GHz 6MB Cache LGA1151 7th Gen.Processor</h2>
						</header>
						<a href="#" class="image full"><img src="images/mp5.jpg" alt=""></a>
						<p>Price Tk 18,900</p>
						<a href="#" class="button">Details</a>
						<a href="#" class="button">Compare</a>
					</section>
					<section class="3u">
						<header>
							<h2>Intel PDC G4400 3.30GHz 6th Gen. Processor</h2>
						</header>
						<a href="#" class="image full"><img src="images/mp4.jpg" alt=""></a>
						<p>Price Tk 7,310</p>
						<a href="#" class="button">Details</a>
						<a href="#" class="button">Compare</a>
					</section>
				</div>
			</div>
			
			<!-- Welcome -->		
			<div id="welcome" class="container">
				<div class="divider"></div>
				<div class="row">
					
				</div>
			</div>
			<!-- /Welcome -->
			
		</div>
		<!-- /Main -->		
		
		<!-- Footer -->
		<div id="footer">
			<div class="container">
				<section>
					<header>
						<h2>New Available!</h2>
						<span class="byline">Checout the latest computer components available in market</span>
					</header>
					<div class="row">
						<section class="4u">
							<a href="#" class="image full"><img src="images/mp1.jpg" alt=""></a>
						</section>
						<section class="4u">
							<a href="#" class="image full"><img src="images/p12.jpg" alt=""></a>
						</section>
						<section class="4u">
							<a href="#" class="image full"><img src="images/p13.jpg" alt=""></a>
						</section>
					</div>
					<a href="#" class="button">Check Now!</a>
				</section>
			</div>
		</div>
		<!-- /Footer -->
		<div>
		
			<button id="loginStatus" class='button3'>
			<?php
				if(isset($_SESSION['login']))
				 {
				 	if($_SESSION['login']==true)
				 	{
						echo '<a style="color: white; text-decoration:none;" href="logout.php">LOG OUT</a>';
				 	}
				 	else
				 	{
				  		echo '<a style="color: white; text-decoration:none;" href="login.html">LOG IN</a>';
				 	}
				 }
				 else
				 {
				 	echo '<a style="color: white; text-decoration:none;"  href="login.html">LOG IN</a>';
				 }
			?>
		 </button>
			
		</div>

		
	</body>
</html>