  
  <?php 
   echo "<pre>";
   echo print_r($GLOBALS);
   echo "</pre>";
   ?>